import glob,json,pathlib,statistics,collections
root=pathlib.Path(__file__).resolve().parent
def rows(name):
    return [json.loads(l) for file in sorted(root.glob(name)) for l in file.read_text().splitlines() if l]
def grouped(data,*keys):
    groups=collections.defaultdict(list)
    for r in data: groups[tuple(r[k] for k in keys)].append(r)
    return sorted(groups.items())
def med(x): return round(statistics.median(x),3) if x else None
def ncache(u): return (u.get("prompt_tokens_details") or {}).get("cached_tokens",0)
for key,rr in grouped(rows("direct-results.jsonl"),"kind","effort"):
    print("worker",key,"correct",sum(r["correct"] for r in rr),"walls",[round(r["wall"],2) for r in rr],"median",med([r["wall"] for r in rr]),"reasoning",med([sum((u.get("completion_tokens_details") or {}).get("reasoning_tokens",0) for u in r["usage"]) for r in rr]))
for key,rr in grouped(rows("cache-results.jsonl"),"repeats","explicit"):
    cold=[r for r in rr if r["step"]==0]; warm=[r for r in rr if r["step"]>0]
    print("prefix",key,"correct",sum(r["correct"] for r in rr),"/",len(rr),"prompt", [r["usage"]["prompt_tokens"] for r in cold],"cold",med([r["wall"] for r in cold]),"warm",med([r["wall"] for r in warm]),"cache",[ncache(r["usage"]) for r in warm],"group",med([sum(r["wall"] for r in rr if r["pair"]==p) for p in set(r["pair"] for r in rr)]))
for key,rr in grouped([r for r in rows("mixed-*.jsonl") if not r["warmup"]],"chunk","series"):
    print("mixed",key,"n",len(rr),"max gap",med([r["gap"] for r in rr if r["gap"]]),"range",[(round(r["gap"] or 0,3),round(r["total"],2)) for r in rr],"long_ttft",med([r["long_ttft"] for r in rr]),"total",med([r["total"] for r in rr]),"correct",sum(r["long_answer"].strip()=="OK" and r["overlap"] and r["short_usage"]["completion_tokens"]==512 for r in rr),"long_prompt/cache",[(r["long_usage"]["prompt_tokens"],ncache(r["long_usage"])) for r in rr])

