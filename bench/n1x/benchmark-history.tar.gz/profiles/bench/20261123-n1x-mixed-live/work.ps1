param([string]$Name,[ValidateSet('probe','route','caps','cache','copy','shared')][string]$Suite,[int]$Port=8002)
$ErrorActionPreference='Stop'
$client=[Net.Http.HttpClient]::new()
$client.Timeout=[timespan]::FromMinutes(3)
$count='Write every integer from 1 to 1000 in ascending order. Put one integer on each line. Begin with 1 and continue without commentary.'
$prose='In at least 300 words, explain how a refrigerator transfers heat, and explain the role of each of the four main components.'
$fresh='Explain in detail how a mechanical clock transfers energy from its mainspring to its escapement. Write at least 400 words.'
$change='First write the integers from 1 through 16, one per line. On the next line write START. Then write every integer starting with 101 in ascending order, one per line, for as long as possible. Output only the requested lines.'
$copyText=((1..16) + @('START') + (101..300)) -join [char]10
$copyPrompt="Transcribe the complete list below exactly, preserving one item per line. Begin with 1 and continue copying through 300. Omit all introductory and closing text. List:`n"+$copyText
function Q($prompt,[int]$seed,[int]$limit){
  @{model='infernix-hc4';messages=@(@{role='user';content=$prompt});temperature=0;seed=$seed;max_tokens=$limit;chat_template_kwargs=@{enable_thinking=$false}}
}
function Wave([string]$case,[array]$requests,[int]$rep){
  $sw=[Diagnostics.Stopwatch]::StartNew()
  $tasks=[Collections.Generic.List[Threading.Tasks.Task]]::new()
  $indexes=[Collections.Generic.List[int]]::new()
  $idxs=0..($requests.Count-1);if($rep%2){[array]::Reverse($idxs)}
  foreach($i in $idxs){
    $payload=[Net.Http.StringContent]::new(($requests[$i]|ConvertTo-Json -Depth 20 -Compress),[Text.Encoding]::UTF8,'application/json')
    $tasks.Add($client.PostAsync("http://127.0.0.1:$Port/v1/chat/completions",$payload));$indexes.Add($i)
  }
  $rows=@(while($tasks.Count){
    $k=[Threading.Tasks.Task]::WaitAny($tasks.ToArray());$time=$sw.Elapsed.TotalSeconds
    $res=$tasks[$k].GetAwaiter().GetResult();$i=$indexes[$k];$tasks.RemoveAt($k);$indexes.RemoveAt($k)
    $raw=$res.Content.ReadAsStringAsync().Result
    if(!$res.IsSuccessStatusCode){throw "$Name $case $i $raw"}
    $r=$raw|ConvertFrom-Json -AsHashtable
    [ordered]@{slot=$i;latency=$time;seed=$requests[$i].seed;limit=$requests[$i].max_tokens;r=$r}
  })
  $record=[ordered]@{name=$Name;case=$case;rep=$rep;wall=($rows.latency|Measure-Object -Maximum).Maximum;rows=$rows}
  ($record|ConvertTo-Json -Depth 28 -Compress)|Add-Content "$PSScriptRoot/$Name-$Suite.jsonl"
  "$Name $case $rep $([Math]::Round($record.wall,3))"
}
if($Suite -eq 'copy'){foreach($rep in 0..2){foreach($limit in 48,96,256){Wave "copy-$limit-110" @((Q $copyPrompt 110 $limit),(Q $fresh 110 $limit)) $rep}};return}
if($Suite -eq 'probe'){Wave probe @((Q $count 111 96),(Q $prose 110 96)) 0;return}
if($Suite -eq 'caps'){
  $q4=@((Q $count 110 128),(Q $prose 110 128),(Q $change 110 128),(Q $fresh 110 128))
  foreach($rep in 0..2){Wave four $q4 $rep; Wave eight ($q4+$q4) $rep}
  if($Name -eq 'base2'){& $PSCommandPath $Name shared}
  if($Name -eq 'base4'){foreach($rep in 0..2){foreach($limit in 48,96,256){Wave "copy-$limit-110" @((Q $copyPrompt 110 $limit),(Q $fresh 110 $limit)) $rep}}}
  return
}
if($Suite -eq 'route'){
 foreach($rep in 0..2){
    $cases=@('DD','MD','DM','MM');if($Name -notlike '*dual*'){$cases=@('DD')};if($rep%2){[array]::Reverse($cases)}
    foreach($case in $cases){Wave $case @((Q $count (110+[int]($case[0] -eq 'M')) 128),(Q $prose (110+[int]($case[1] -eq 'M')) 128)) $rep}
    foreach($limit in 48,96,256){
       $seeds=@(if($Name -like '*dual*'){110,111,112,113}else{110})
       if($rep%2){[array]::Reverse($seeds)}
       foreach($seed in $seeds){Wave "copy-$limit-$seed" @((Q $copyPrompt $seed $limit),(Q $fresh 110 $limit)) $rep}
    }
 };return
}
$fixture=(Get-Content "$PSScriptRoot/../20261122-n1x-best/dffasteager-1.json" -Raw|ConvertFrom-Json -AsHashtable)
# Both sessions share the archive but request different SKUs after it.
if($Suite -eq 'shared'){
 foreach($rep in 0..1){
   $qs=@(foreach($i in 0,1){
     $serialized=($fixture.rows[2].request|ConvertTo-Json -Depth 24).Replace('AGENT-0000',('AGENT-{0:D4}' -f $i)).Replace('AX-0-0',"AX-$i-0")
     $q=$serialized|ConvertFrom-Json -AsHashtable
     $q.messages[0].content="Shared archive $rep. "+$q.messages[0].content
     $q.messages[-1].content=(@{sku="AX-$i-0";count=23+7*$i}|ConvertTo-Json -Compress)
     $q.seed=110
     $q
   })
   Wave shared-prime @($qs[0]) $rep
   $order=if($rep){111,110}else{110,111}
   foreach($seed in $order){$qs[0].seed=$seed;Wave "shared-warm-$seed" $qs $rep}
 }
}
if($Suite -eq 'shared'){return}

foreach($rep in 0..1){
 foreach($seed in $(if($Name -like '*dual*'){110,111}else{@(110)})){
 $qs=@(foreach($i in 0,1){
    $serialized=($fixture.rows[2].request|ConvertTo-Json -Depth 24).Replace('AGENT-0000',('AGENT-{0:D4}' -f $i)).Replace('AX-0-0',"AX-$i-0")
  $q=$serialized|ConvertFrom-Json -AsHashtable
  $q.messages[-1].content=(@{sku="AX-$i-0";count=23+7*$i}|ConvertTo-Json -Compress)
  $q.messages[0].content="Trial $rep head $seed session $i. "+$q.messages[0].content
  $q.seed=if($i){110}else{$seed}
  $q
 })
 foreach($state in 'cold','warm'){Wave "tool-$seed-$state" $qs $rep}
 }
}

