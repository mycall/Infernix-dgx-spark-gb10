from settings import effective
route, timeout = effective('prod')
