param([int]$Before)
$ErrorActionPreference='Stop'
if(Get-Process -Id $Before -ErrorAction SilentlyContinue){Wait-Process -Id $Before -ErrorAction SilentlyContinue}
if(@(Get-Content "$PSScriptRoot/base4-caps.jsonl").Count -ne 6){throw 'baseline incomplete'}
function StopTrial([string]$Name){
  wslc logs $Name 2>&1|Out-File "$PSScriptRoot/$Name.log" -Encoding utf8
  wslc stop $Name
  if($LASTEXITCODE){throw "stop $Name failed"}
}
& "$PSScriptRoot/work.ps1" base4 copy
StopTrial n1x-live-b4
& "$PSScriptRoot/launch.ps1" n1x-live-dual3 4 -Dual
& "$PSScriptRoot/work.ps1" dual probe
& "$PSScriptRoot/work.ps1" dual route
& "$PSScriptRoot/work.ps1" dual cache
StopTrial n1x-live-dual3
foreach($cap in 8,2,1){
 $name="n1x-live-b$cap"
 & "$PSScriptRoot/launch.ps1" $name $cap
 & "$PSScriptRoot/work.ps1" "base$cap" caps
 StopTrial $name
}
