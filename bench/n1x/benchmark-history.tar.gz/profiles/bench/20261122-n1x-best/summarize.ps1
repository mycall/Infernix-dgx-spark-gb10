$ErrorActionPreference='Stop'
$dir=$PSScriptRoot
$base='C:\Users\michael\source\github\mycall\n1x-ai\results\benchmarks\20261121-213108-qwen38fn-best-agents\agents'
$ref=@(Get-Content "$base/responses.jsonl" | ForEach-Object {ConvertFrom-Json $_ -AsHashtable})
$old=Get-Content "$base/summary.json" -Raw|ConvertFrom-Json -AsHashtable
$rows=[Collections.Generic.List[object]]::new()
function Add-Result($v,$i,$correct,$task,$setup,$ttft,$phase,$tokens,$seconds,$cache){
    $rows.Add([pscustomobject][ordered]@{variant=$v;trial=$i;correct=$correct;task_s=$task;setup_s=$setup;setup_ttft_s=$ttft;scored_phase_ttft_s=$phase;scored_generation_tokens=($tokens[0]+$tokens[1]);tool_output_tokens=$tokens[0];final_output_tokens=$tokens[1];scored_decode_seconds=($seconds[0]+$seconds[1]);scored_decode_toks_s=(($tokens[0]+$tokens[1]-2)/($seconds[0]+$seconds[1]));tool_cached_tokens=$cache[0];final_cached_tokens=$cache[1]})
}
foreach($o in $old){
    $i=[int]$o.repeat; $j=3*$i; $setup=$ref[$j];$tool=$ref[$j+1].timing;$final=$ref[$j+2].timing
    Add-Result qwen38fn-best $i ([bool]$o.correct_tasks) $o.elapsed_s $setup.elapsed_s $setup.timing.pp_s ($tool.pp_s+$final.pp_s) @($tool.completion_tokens,$final.completion_tokens) @($tool.decode_s,$final.decode_s) @($tool.cached_tokens,$final.cached_tokens)
}
foreach($f in Get-ChildItem $dir -File | Where-Object Name -match '^(plain|mtp|mtp4k|mtp4k-low|mtp4k-boundary|dflash4k|dfnative|dfnarrow|dfpatched|dffasteager|dfeager|dfexact)-[01]\.json$'){
    $o=Get-Content $f.FullName -Raw|ConvertFrom-Json -AsHashtable
    if($o.rows.Count -lt 3){
        $rows.Add([pscustomobject][ordered]@{variant=$o.variant;trial=$o.trial;correct=$false;task_s=$null;setup_s=$o.rows[0].wall_s;setup_ttft_s=$o.rows[0].response.timings.prompt_ms/1000;scored_phase_ttft_s=$null;scored_generation_tokens=$null;tool_output_tokens=$null;final_output_tokens=$null;scored_decode_seconds=$null;scored_decode_toks_s=$null;tool_cached_tokens=$null;final_cached_tokens=$null})
        continue
    }
    $t=$o.rows[1].response.timings;$u=$o.rows[2].response.timings
    Add-Result $o.variant $o.trial $o.correct $o.task_s $o.rows[0].wall_s ($o.rows[0].response.timings.prompt_ms/1000) (($t.prompt_ms+$u.prompt_ms)/1000) @($t.predicted_n,$u.predicted_n) @(($t.predicted_ms/1000),($u.predicted_ms/1000)) @($t.cache_n,$u.cache_n)
}
$labels=@{
    'dflash4k'='DFlash2 K3 / 4096 / original repo template'
    'dfnarrow'='DFlash2 K3 / 4096 / corrected repo template'
    'dfpatched'='DFlash2 K3 / 4096 / corrected repo template'
    'dfnative'='DFlash2 K3 / 4096 / artifact template'
    'mtp'='MTP auto / 512'
    'mtp4k'='MTP auto / 4096'
    'mtp4k-low'='MTP auto / 4096 / low effort'
    'mtp4k-boundary'='MTP auto / 4096 / explicit breakpoint'
    'dfexact'='DFlash2 K3 / 4096 / reproducible'
    'dfeager'='DFlash2 K3 / 4096 / reproducible eager'
    'dffasteager'='DFlash2 K3 / 4096 / corrected template / eager (WSLC)'
    'plain'='Plain / 512'
}
foreach($r in $rows){if($labels.ContainsKey($r.variant)){$r.variant=$labels[$r.variant]}}
$rows|Export-Csv "$dir/results.csv"
$fixed=foreach($f in Get-ChildItem $dir -Filter '*-fixed128.json'){
    $o=Get-Content $f.FullName -Raw|ConvertFrom-Json -AsHashtable
    foreach($r in $o.rows){$res=$r.response;$bytes=[Text.Encoding]::UTF8.GetBytes($res.choices[0].message.content);[pscustomobject]@{run=$f.BaseName.Replace('-fixed128','');repeat=$r.repeat;tokens=$res.timings.predicted_n;decoded_s=$res.timings.predicted_ms/1000;tokens_s=$res.timings.predicted_per_second;finish=$res.choices[0].finish_reason;content_sha256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes));sequential_1_to_46=($res.choices[0].message.content.Trim() -ceq ((1..46) -join [char]10))}}
}
$fixed|Export-Csv "$dir/fixed128.csv"
$rows|Format-Table variant,trial,correct,task_s,setup_s,setup_ttft_s,scored_generation_tokens,scored_decode_toks_s -AutoSize









