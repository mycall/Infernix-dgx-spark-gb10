import concurrent.futures, json, re, time, threading, urllib.request
from pathlib import Path
import sys
base=sys.argv[1]
def metrics():
    raw=urllib.request.urlopen(base+'/metrics',timeout=5).read().decode()
    return {int(k):int(v) for k,v in re.findall(r'^infernix_decode_batch_rounds_total\{batch="(\d+)"\} (\d+)$',raw,re.M)}
def chat(msg,tool,choice):
    body=dict(model='infernix-hc4',messages=msg,temperature=0,max_tokens=output_cap,
              tools=[tool],tool_choice=choice,chat_template_kwargs={'enable_thinking':False},
              stream=True,stream_options={'include_usage':True})
    req=urllib.request.Request(base+'/v1/chat/completions',data=json.dumps(body).encode(),headers={'Content-Type':'application/json'})
    t0=time.monotonic()
    first=None; content=''; called={}; usage={}; finish=None
    with urllib.request.urlopen(req,timeout=180) as resp:
        for raw in resp:
            if not raw.startswith(b'data:'):continue
            data=raw[5:].strip()
            if data==b'[DONE]':break
            chunk=json.loads(data)
            if chunk.get('usage'):usage=chunk['usage']
            for c in chunk.get('choices',[]):
                delta=c['delta']
                if first is None and any(delta.get(k) for k in ['content','reasoning','reasoning_content','tool_calls']):
                    first=time.monotonic()-t0
                content+=delta.get('content') or ''
                if c.get('finish_reason'):finish=c['finish_reason']
                for call in delta.get('tool_calls',[]):
                    row=called.setdefault(call['index'],{'id':'','type':'function','function':{'name':'','arguments':''}})
                    row['id']+=call.get('id','')
                    for k in ['name','arguments']:row['function'][k]+=call.get('function',{}).get(k,'')
    return content,list(called.values()),dict(ttft_s=first,elapsed_s=time.monotonic()-t0,finish=finish,usage=usage)

tool={'type':'function','function':{'name':'read_file','description':'Read the requested Python source file.','parameters':{'type':'object','properties':{'path':{'type':'string'}},'required':['path']}}}
modules=['catalog','ledger','manifest','tariffs']
def client(i,tag):
    module=modules[i];path=f'src/{tag}/{module}.py'
    prompt=f'You are auditing {path}. Call read_file on that path. Then return a JSON array containing exactly the names of the public functions in source order. Exclude functions starting with an underscore. No markdown.'
    messages=[{'role':'user','content':prompt}]
    _,calls,timing=chat(messages,tool,'auto')
    trace=dict(worker=i,path=path,selection=timing,calls=calls,correct=False)
    if len(calls)!=1 or calls[0]['function']['name']!='read_file' or json.loads(calls[0]['function']['arguments'])!={'path':path}:return trace
    source=[];expected=[]
    for k in range(24):
        name=f'{module}_stage_{k:02}'; expected.append(name)
        source.extend([f'def _helper_{k:02}(row):',f'    return row.get("stage_{k:02}", 0)','',
                       f'def {name}(row):',f'    """Read stage {k:02} from the current row."""',f'    return _helper_{k:02}(row)',''])
    messages.extend([{'role':'assistant','content':None,'tool_calls':calls},{'role':'tool','tool_call_id':calls[0]['id'],'content':'\n'.join(source)}])
    answer,_,timing=chat(messages,tool,'none')
    trace.update(final=timing,answer=answer)
    try:trace['correct']=json.loads(answer)==expected
    except ValueError:pass
    return trace
def run(j,concurrency,count):
    before=metrics(); start=time.monotonic()
    with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as pool:
        fs=[pool.submit(client,i,f'trial{j:02}') for i in range(count)]
        results=[]
        for fut in fs:
            try:results.append(fut.result())
            except Exception as exc:results.append(dict(error=repr(exc),correct=False))
    elapsed=time.monotonic()-start;after=metrics()
    out=dict(clients=concurrency,tasks=count,wall_s=elapsed,rounds={b:after[b]-v for b,v in before.items() if after[b]!=v},results=results)
    print(concurrency,count,round(elapsed,3),out['rounds'],[x['correct'] for x in results],flush=True)
    Path(f'run-{j}.json').write_text(json.dumps(out,indent=2))

for j,output_cap in enumerate((256000,8192,8192,256000)):
    run(j,2,2)
