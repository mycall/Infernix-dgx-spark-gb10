param([string]$Previous,[string]$Variant,[int]$Trial,[int]$Chunk=512)
$ErrorActionPreference='Stop'
$old="infernix-bench-$Previous"
wslc logs $old 2>&1|Out-File "$PSScriptRoot/$Previous.log"
wslc stop $old
if($LASTEXITCODE){throw "stop failed: $old"}
& "$PSScriptRoot/launch.ps1" $Variant $Trial $Chunk
if($LASTEXITCODE){throw "launch failed: $Variant-$Trial"}
& "$PSScriptRoot/ready.ps1" "infernix-bench-$Variant-$Trial"
& "$PSScriptRoot/replay.ps1" $Variant $Trial $Trial
& "$PSScriptRoot/fixed.ps1" $Variant $Trial

