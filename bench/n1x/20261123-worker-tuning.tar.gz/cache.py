"""Paired two-read tool loops. Only the stable system text gets an explicit marker."""
import hashlib, json, pathlib, time, urllib.request
root = pathlib.Path(__file__).resolve().parent
tool = {"type":"function","function":{"name":"read_file","description":"Read one file by path.","parameters":{"type":"object","properties":{"path":{"type":"string"}},"required":["path"]}}}
url = "http://127.0.0.1:8001/v1/chat/completions"
for pair in range(3):
    for repeats in [250,900]:
        for explicit in ([False,True] if pair%2==0 else [True,False]):
            salt = hashlib.sha256(f"cache-tune-{pair}-{repeats}-{explicit}".encode()).hexdigest()[:16]
            prefix = f"Case {salt}. You are a repository reader. Use read_file as instructed. Reference glossary:\n" + "A region contains numbered shelves for public archival reference.\n"*repeats
            part = {"type":"text","text":prefix}
            if explicit: part["prompt_cache_breakpoint"]={"mode":"explicit"}
            msgs = [{"role":"system","content":[part]},{"role":"user","content":"Read index.txt, then read the file named inside it, then reply with only the release marker from that file."}]
            marker = "amber-"+salt[-6:]
            for step, filename in enumerate(["index.txt","active.txt",None]):
                req={"model":"infernix-hc4","messages":msgs,"tools":[tool],"temperature":0,"max_tokens":128,"chat_template_kwargs":{"enable_thinking":False}}
                start=time.monotonic()
                with urllib.request.urlopen(urllib.request.Request(url,json.dumps(req).encode(),{"Content-Type":"application/json"}),timeout=100) as f: reply=json.load(f)
                wall=time.monotonic()-start
                msg=reply["choices"][0]["message"]
                calls=msg.get("tool_calls") or []
                actual=None
                if calls:
                    actual=json.loads(calls[0]["function"]["arguments"]).get("path")
                correct = (len(calls)==1 and calls[0]["function"]["name"]=="read_file" and actual==filename) if filename else (msg.get("content") or "").strip()==marker
                row=dict(pair=pair,repeats=repeats,explicit=explicit,step=step,correct=correct,wall=round(wall,4),usage=reply["usage"],timings=reply.get("timings"),actual=actual if calls else msg.get("content"))
                with (root/"cache-results.jsonl").open("a") as f: print(json.dumps(row),file=f)
                if not correct or not filename: break
                msgs.append({"role":"assistant","content":msg.get("content") or "","tool_calls":calls})
                msgs.append({"role":"tool","tool_call_id":calls[0]["id"],"content":"active.txt" if step==0 else "release marker: "+marker})
            print(pair,repeats,explicit,step,correct,flush=True)


