param([string]$Backend,[string]$Root='http://127.0.0.1:8002',[string]$Cells='1,2,3,4',[int]$Trials=2)
$ErrorActionPreference='Stop'
$client=[Net.Http.HttpClient]::new()
$client.Timeout=[TimeSpan]::FromMinutes(8)
$source=Get-Content (Join-Path $PSScriptRoot '../20261122-n1x-best/dffasteager-1.json') -Raw|ConvertFrom-Json -AsHashtable
$results=[Collections.Generic.List[object]]::new()
function Batch([array]$qs,[string]$work,[string]$phase){
  $bodies=@($qs|ForEach-Object {[Net.Http.StringContent]::new((ConvertTo-Json $_ -Depth 32 -Compress),[Text.Encoding]::UTF8,'application/json')})
  $sw=[Diagnostics.Stopwatch]::StartNew()
  $jobs=@(foreach($body in $bodies){$client.PostAsync("$Root/v1/chat/completions",$body)})
  $rows=@(foreach($job in $jobs){
    $h=$job.GetAwaiter().GetResult()
    $raw=$h.Content.ReadAsStringAsync().GetAwaiter().GetResult()
    $body=ConvertFrom-Json $raw -AsHashtable
    [ordered]@{status=[int]$h.StatusCode;response=$body}
  })
  $sw.Stop()
  $o=[ordered]@{work=$work;phase=$phase;trial=$trial;clients=$c;wall_s=$sw.Elapsed.TotalSeconds;rows=$rows}
  $results.Add($o)
  if(@($rows|Where-Object status -ne 200).Count){$results|ConvertTo-Json -Depth 30|Set-Content "$PSScriptRoot/grid-$Backend.json";throw "$Backend $work $phase HTTP error"}
  return $o
}
foreach($trial in 0..($Trials-1)){
  $points=@($Cells.Split(',')|%{[int]$_});if($trial -eq 1){[array]::Reverse($points)}
  foreach($c in $points){
    foreach($work in 'count','explanation'){
      $prompt=if($work -eq 'count'){'Write every integer from 1 to 1000 in ascending order. Put one integer on each line. Begin with 1 and continue without commentary.'}else{'In at least 300 words, explain how a refrigerator transfers heat, and explain the role of each of the four main components.'}
      $qs=@(foreach($i in 0..($c-1)){@{model='infernix-hc4';messages=@(@{role='user';content=$prompt});chat_template_kwargs=@{enable_thinking=$false};temperature=0;max_tokens=128}})
      $item=Batch $qs $work decode
      foreach($r in $item.rows){$r['passed']=($r.response.usage.completion_tokens -eq 128 -and $r.response.choices[0].finish_reason -eq 'length')
        if($work -eq 'count'){$r.passed=$r.passed -and ($r.response.choices[0].message.content.Trim() -ceq ((1..46) -join [char]10))}}
    }
    $qs=@(foreach($i in 0..($c-1)){
      $q=$source.rows[0].request.Clone()
      $code='AGENT-{0:D4}' -f $i
      $q.messages=@(@{role='system';content=("Session $trial/$c/$i. "+$source.rows[0].request.messages[0].content)},@{role='user';content=$source.rows[0].request.messages[1].content.Replace('AGENT-0000',$code)})
      $q
    })
    $a=Batch $qs inventory setup
    foreach($i in 0..($c-1)){
      $m=$a.rows[$i].response.choices[0]
      $a.rows[$i]['passed']=($m.finish_reason -eq 'stop' -and $m.message.content.Trim() -ceq 'READY')
      $qs[$i].messages+=@{role='assistant';content=$m.message.content}
      $qs[$i].messages+=@{role='user';content=$source.rows[1].request.messages[-1].content.Replace('AX-0-0',"AX-$i-0")}
    }
    $b=Batch $qs inventory tool
    foreach($i in 0..($c-1)){
      $m=$b.rows[$i].response.choices[0];$calls=$m.message.tool_calls
      $ok=$calls.Count -eq 1 -and $m.finish_reason -eq 'tool_calls' -and $calls[0].function.name -ceq 'lookup_inventory' -and ($calls[0].function.arguments|ConvertFrom-Json).sku -ceq "AX-$i-0"
      $b.rows[$i]['passed']=$ok
      if(!$ok){continue}
      $msg=@{role='assistant';content=$m.message.content;tool_calls=$calls}
      foreach($k in 'reasoning_content','reasoning'){if($m.message[$k]){$msg.reasoning=$m.message[$k];break}}
      $qs[$i].messages+=$msg
      $qs[$i].messages+=@{role='tool';tool_call_id=$calls[0].id;content=(@{sku="AX-$i-0";count=23+$i*7}|ConvertTo-Json -Compress)}
      $qs[$i].tool_choice='none'
    }
    $valid=@(0..($c-1)|Where-Object{$b.rows[$_].passed})
    if($valid.Count){
      $f=Batch @($valid|%{$qs[$_]}) inventory final
      foreach($k in 0..($valid.Count-1)){$i=$valid[$k];$m=$f.rows[$k].response.choices[0];$f.rows[$k]['session']=$i;$f.rows[$k]['passed']=($m.finish_reason -eq 'stop' -and $m.message.content.Trim() -ceq ('AGENT-{0:D4}:{1}' -f $i,(23+$i*7)))}
    }
    $results|ConvertTo-Json -Depth 32|Set-Content "$PSScriptRoot/grid-$Backend.json"
    "$Backend trial=$trial C=$c setup=$([Math]::Round($a.wall_s,2)) tool=$([Math]::Round($b.wall_s,2)) valid_calls=$($valid.Count)/$c"
  }
}
