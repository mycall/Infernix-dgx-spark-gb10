const fs=require('fs'),path=require('path');
const dir=__dirname;
const load=name=>fs.readFileSync(path.join(dir,name),'utf8').trim().split(/\r?\n/).map(s=>JSON.parse(s.replace(/^\uFEFF/,'')));
const logs=fs.readFileSync(path.join(dir,'n1x-live-dual3.log'),'utf8').split(/\r?\n/);
const waves=[...load('dual-probe.jsonl'),...load('dual-route.jsonl'),...load('dual-cache.jsonl')];
let index=-1,completed=2;
const rows=[];
for(const line of logs){
 if(/req#\d+ started/.test(line) && completed===2){index++;completed=0}
 if(/req#\d+ done/.test(line)){completed++}
 const m=line.match(/trial round seed=(\d+) lane=(\d+) from=(\d+) to=(\d+) head=(\w+) batch=(\d+) ms=([\d.]+)/);
 if(!m||index<0||!waves[index])continue;
 rows.push({case:waves[index].case,rep:waves[index].rep,seed:+m[1],lane:+m[2],from:+m[3],to:+m[4],head:m[5],batch:+m[6],ms:+m[7]});
}
const toCsv=(p,arr)=>fs.writeFileSync(path.join(dir,p),[Object.keys(arr[0]).join(','),...arr.map(r=>Object.values(r).join(','))].join('\n'));
toCsv('round-times.csv',rows);
const arr=a=>[...a].sort((a,b)=>a-b);
const med=a=>{a=arr(a);return a.length?+((a[(a.length-1)>>1]+a[a.length>>1])/2).toFixed(2):null};
const group=new Map();
for(const r of rows){
 if(!r.case.startsWith('copy-')||r.batch!==2)continue;
 const [,len,src]=r.case.split('-');if(r.seed!==+src)continue;
 // Seed 110 appears on both rows. Identify the copy row for DD via its first-window route's committed stride.
 if(r.seed===110)continue;
 for(const cut of [32,64]){
 const key=[r.case,r.rep,r.lane,cut].join('/');
 if(r.from<cut||r.from>cut+4||group.has(key))continue;
 group.set(key,{...r,cut});
 }
}
for(const cut of [32,64])for(const seed of [111,112,113]){
 const data=[...group.values()].filter(r=>r.cut===cut&&r.seed===seed);
 console.log('first round at',cut,'seed',seed,'n',data.length,'median ms',med(data.map(x=>x.ms)),'range',arr(data.map(x=>x.ms)).filter((v,i,a)=>i===0||i===a.length-1));
}
const reference=[...load('base4-route.jsonl'),...load('base4-copy.jsonl')];
for(const family of ['count/prose','copy/clock']){
 const cases=new Map();
 for(const w of waves){
 let key;
 if(family==='count/prose' && /^[DM]{2}$/.test(w.case))key='DD';
 else if(family==='copy/clock'&&w.case.startsWith('copy-'))key=w.case.replace(/-\d+$/,'-110');
 else continue;
 const ref=reference.find(v=>v.case===key&&v.rep===w.rep);
 const equal=w.rows.map(r=>[r.slot,r.r.choices[0].message.content===ref.rows.find(x=>x.slot===r.slot).r.choices[0].message.content]);
 const k=family==='copy/clock'?w.case.split('-')[2]:w.case;
 const v=cases.get(k)||[0,0,0];for(const [s,e]of equal)v[s]+=e?1:0;v[2]++;cases.set(k,v);
 }
 console.log(family,[...cases]);
}
