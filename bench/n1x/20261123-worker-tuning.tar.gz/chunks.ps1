[CmdletBinding()]
param([string]$Engine, [string]$Manager)
$ErrorActionPreference = 'Stop'
$daily = 'infernix-n1x-hc4-256k'
function Wait-Ready([int]$Port) {
    $deadline = (Get-Date).AddMinutes(7)
    do {
        try {
            $models = Invoke-RestMethod "http://127.0.0.1:$Port/v1/models" -TimeoutSec 3
            if ($models.data.id -contains 'infernix-hc4') { return }
        } catch {}
        Start-Sleep -Seconds 3
    } while ((Get-Date) -lt $deadline)
    throw "No healthy model on port $Port"
}
function Assert-Idle([int]$Port) {
    $metrics = (Invoke-WebRequest "http://127.0.0.1:$Port/metrics" -TimeoutSec 4).Content
    foreach ($state in 'running','waiting','paused') {
        if ($metrics -notmatch "(?m)^infernix_requests_$state 0\s*$") { throw "Engine on $Port has $state work." }
    }
}
function Invoke-Mixed([int]$Port,[int]$Chunk,[string]$Series) {
    & py -3 "$PSScriptRoot/mixed.py" $Port $Chunk $Series
    if ($LASTEXITCODE -ne 0) { throw "Failed mixed load for $Chunk" }
}
Assert-Idle 8001
& py -3 "$PSScriptRoot/cache_control.py"
if ($LASTEXITCODE -ne 0) { throw 'Cache control failed' }
& wslc logs infernix-n1x-hc4-256k 2>&1 | ForEach-Object { "$_" } | Select-String 'req#\d+ (started|done)' | ForEach-Object { $_.Line } | Set-Content "$PSScriptRoot/worker-engine.log"
Invoke-Mixed 8001 4096 primary
& wslc logs --tail 220 $daily 2>&1 | ForEach-Object { "$_" } | Set-Content "$PSScriptRoot/engine-4096-primary.log"
Assert-Idle 8001
& wslc stop $daily
if ($LASTEXITCODE -ne 0) { throw 'Could not stop daily service' }
try {
    foreach ($chunk in 2048,8192) {
        $name = "infernix-tune-20261123-$chunk"
        $existing = @(& wslc ps -a --format json | ForEach-Object { ($_ | ConvertFrom-Json).Names })
        if ($name -in $existing) { throw "Name already in use: $name" }
        $arguments = (& "$Engine/tools/run_wslc_hc4_dflash2.ps1" -PrintOnly -Name $name -Port 8003 | Out-String | ConvertFrom-Json)
        $chunkIndex = [array]::IndexOf($arguments, '--prefill-chunk')
        if ($chunkIndex -lt 0) { throw 'Missing prefill option' }
        $arguments[$chunkIndex+1] = [string]$chunk
        & wslc @arguments
        if ($LASTEXITCODE -ne 0) { throw "Could not start $name" }
        try {
            Wait-Ready 8003
            Invoke-Mixed 8003 $chunk primary
        } finally {
            & wslc logs $name 2>&1 | ForEach-Object { "$_" } | Set-Content "$PSScriptRoot/engine-$chunk.log"
            & wslc stop $name
            if ($LASTEXITCODE -eq 0) { & wslc container remove $name }
        }
    }
} finally {
    & "$Manager/n1x.ps1" start -Profile infernix-hc4
    Wait-Ready 8001
}
Invoke-Mixed 8001 4096 repeat
& "$Manager/n1x.ps1" test -Profile infernix-hc4
if ($LASTEXITCODE -ne 0) { throw 'Daily profile test failed' }

