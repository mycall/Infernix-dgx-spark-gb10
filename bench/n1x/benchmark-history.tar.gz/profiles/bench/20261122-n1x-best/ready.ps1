param([string]$Name)
$ErrorActionPreference='Stop'
$ready=& wslc logs --follow $Name 2>&1 | ForEach-Object { "$_" } | Where-Object { $_ -match 'listening on http|FATAL| ERROR ' } | Select-Object -First 1
if($ready -notmatch 'listening on http'){throw "Startup failed: $ready"}
$ready
