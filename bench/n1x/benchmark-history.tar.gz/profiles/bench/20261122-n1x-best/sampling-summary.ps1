$dir=$PSScriptRoot
$summary=foreach($f in Get-ChildItem $dir -Filter '*-sampled.json'){
    $rows=Get-Content $f.FullName -Raw|ConvertFrom-Json -AsHashtable
    $bad=@($rows|Where-Object status -ne 200)
    $seedGroups=$rows|Group-Object {$_['seed']}
    $paired=0
    $changed=[Collections.Generic.List[int]]::new()
    foreach($g in $seedGroups){
        if($g.Count -eq 2 -and $g.Group[0].status -eq 200 -and $g.Group[1].status -eq 200){
            $paired++
            $a=$g.Group[0].response.choices[0].message
            $b=$g.Group[1].response.choices[0].message
            if($a.reasoning_content -cne $b.reasoning_content -or $a.content -cne $b.content){$changed.Add([int]$g.Name)}
        }
    }
    [pscustomobject]@{profile_test=$f.BaseName;requests=$rows.Count;http_errors=$bad.Count;failed_seeds=(@($bad|ForEach-Object seed|Sort-Object -Unique) -join ',');valid_seed_pairs=$paired;different_pairs=$changed.Count;different_seeds=($changed -join ',')}
}
$summary|Export-Csv "$dir/sampling.csv"
$summary|Format-Table -AutoSize
