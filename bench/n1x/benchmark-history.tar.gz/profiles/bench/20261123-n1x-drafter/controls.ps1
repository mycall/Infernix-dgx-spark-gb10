param([string]$Variant,[string]$Root='http://127.0.0.1:8002')
$ErrorActionPreference='Stop'
$base=@{model='infernix-hc4';chat_template_kwargs=@{enable_thinking=$false};temperature=0;max_tokens=128}
$q=Get-Content (Join-Path $PSScriptRoot '../20261122-n1x-best/dffasteager-1.json') -Raw|ConvertFrom-Json -AsHashtable
$archive=$q.rows[0].request.messages[1].content
$archive=$archive.Substring(0,$archive.LastIndexOf('Session code is'))
$records=foreach($run in 0..2){
  foreach($work in @('alphabet','long-count','explanation')){
    $prompt=switch($work){
     alphabet {'Repeat the lowercase English alphabet, one letter per line, cycling from a to z until you have written 400 letters. Begin immediately with a.'}
     long-count {$archive+"`nYou have finished reading the records. Write every integer from 1 to 1000 in ascending order. Put one integer on each line. Begin with 1 and continue without commentary."}
     explanation {'In at least 300 words, explain how a refrigerator transfers heat, and explain the role of each of the four main components.'}
    }
    $q=$base.Clone()
    $q.messages=@(@{role='user';content=$prompt})
    $r=Invoke-RestMethod "$Root/v1/chat/completions" -ContentType application/json -Method Post -Body ($q|ConvertTo-Json -Depth 8 -Compress)
    [pscustomobject]@{work=$work;repeat=$run;response=$r}
  }
}
$records|ConvertTo-Json -Depth 20|Set-Content "$PSScriptRoot/$Variant-controls.json"
