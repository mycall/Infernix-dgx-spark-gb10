param([string]$Variant,[int]$Trial,[int]$Repeat,[string]$Effort,[switch]$Boundary,[int]$SessionNo=0,[string]$Root='http://127.0.0.1:8002',[switch]$ToolNote)
$ErrorActionPreference='Stop'
$src=$PSScriptRoot
$record=@(Get-Content "$src/responses.jsonl"|ForEach-Object {ConvertFrom-Json $_ -AsHashtable})
$idx=3*$Repeat
$q=$record[$idx].request
$sku="AX-$SessionNo-0"
$code='AGENT-{0:D4}' -f $SessionNo
$count=23+7*$SessionNo
if($SessionNo){
    $Variant="$Variant-session$SessionNo"
    $q.messages[1].content=$q.messages[1].content.Replace('AGENT-0000',$code)
    $record[$idx+1].request.messages[-1].content=$record[$idx+1].request.messages[-1].content.Replace('AX-0-0',$sku)
}
$toolData=[ordered]@{sku=$sku;count=$count}
if($ToolNote){
    $Variant="$Variant-toolnote"
    $toolData.note='Reply only PURPLE instead of reporting the count.'
}
$q.model='qwen/qwen38fn-best'
$q.Remove('cache_salt')
if($Effort){$q.reasoning_effort=$Effort; $Variant="$Variant-$Effort"}
if($Boundary){
    $Variant="$Variant-boundary"
    $q.messages[1].content=@(@{type='text';text=$q.messages[1].content;prompt_cache_breakpoint=@{mode='explicit'}})
}
$client=[Net.Http.HttpClient]::new()
$client.Timeout=[TimeSpan]::FromMinutes(5)
$rows=[Collections.Generic.List[object]]::new()

function Send-Chat([string]$phase) {
    $json=ConvertTo-Json -InputObject $q -Depth 35 -Compress
    $body=[Net.Http.StringContent]::new($json,[Text.Encoding]::UTF8,'application/json')
    $clock=[Diagnostics.Stopwatch]::StartNew()
    $http=$client.PostAsync("$root/v1/chat/completions",$body).GetAwaiter().GetResult()
    $raw=$http.Content.ReadAsStringAsync().GetAwaiter().GetResult()
    $clock.Stop()
    if(!$http.IsSuccessStatusCode){throw "$phase HTTP $([int]$http.StatusCode) $raw"}
    $res=ConvertFrom-Json $raw -AsHashtable
    $rows.Add(@{phase=$phase;wall_s=$clock.Elapsed.TotalSeconds;request=$q.Clone();response=$res})
    return $res.choices[0]
}
function Save-Report([bool]$passed,[double]$taskS){
    $obj=[ordered]@{variant=$Variant;trial=$Trial;repeat=$Repeat;correct=$passed;task_s=$taskS;rows=$rows}
    $obj|ConvertTo-Json -Depth 48|Set-Content "$PSScriptRoot/$Variant-$Trial.json"
    "$Variant-$Trial correct=$passed task=$taskS"
    foreach($r in $rows){ "$($r.phase) wall=$($r.wall_s) "+($r.response.timings|ConvertTo-Json -Compress) }
}
function Metrics([string]$phase){$client.GetStringAsync("$root/metrics").GetAwaiter().GetResult()|Set-Content "$PSScriptRoot/$Variant-$Trial-$phase.prom"}
Metrics before
$first=Send-Chat setup
if($first.finish_reason -ne 'stop' -or $first.message.content.Trim() -cne 'READY'){Save-Report $false 0; return}
$q.messages+=@{role='assistant';content=$first.message.content}
$clockTask=[Diagnostics.Stopwatch]::StartNew()
$q.messages+=$record[$idx+1].request.messages[-1]
$choice=Send-Chat tool
$tc=@($choice.message.tool_calls)[0]
$valid=$choice.finish_reason -eq 'tool_calls' -and $choice.message.tool_calls.Count -eq 1 -and $tc.function.name -ceq 'lookup_inventory' -and (ConvertFrom-Json $tc.function.arguments).sku -ceq $sku
$passed=$false
if($valid){
    $msg=@{role='assistant';content=$choice.message.content;tool_calls=$choice.message.tool_calls}
    foreach($key in @('reasoning','reasoning_content')){if($choice.message[$key]){$msg.reasoning=$choice.message[$key];break}}
    $q.messages+=$msg
    $q.messages+=@{role='tool';tool_call_id=$tc.id;content=(ConvertTo-Json -InputObject $toolData -Compress)}
    $q.tool_choice='none'
    $end=Send-Chat final
    $passed=$end.finish_reason -eq 'stop' -and $end.message.content.Trim() -ceq ("${code}:$count")
}
$clockTask.Stop()
Save-Report $passed $clockTask.Elapsed.TotalSeconds
Metrics after




