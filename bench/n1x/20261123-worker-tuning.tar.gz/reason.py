"""Paired OpenCode Explore worker trials on two synthetic repository questions."""
import json, os, pathlib, subprocess, time, sys
from datetime import datetime, timezone
root = pathlib.Path(__file__).resolve().parent
home = pathlib.Path.home()
cli = home / ".opencode/bin/opencode.exe"
config = json.loads((home / ".config/opencode/infernix-parallel.jsonc").read_text(encoding="utf-8-sig"))
verified = "--verified" in sys.argv
order = ["low","default","default","low"] if verified else ["default","low","low","default","default","low"]
for ordinal, effort in enumerate(order):
    run = ordinal + (6 if verified else 0)
    pair = ordinal // 2
    path = root / f"fixture-{run}"
    path.mkdir(exist_ok=True)
    marker = ["amber-72","birch-36","coral-51"][pair]
    route = ["north-archive", "east-ledger", "west-index"][pair]
    timeout = [47,83,61][pair]
    (path/"version.txt").write_text(f"release_marker={marker}\n")
    (path/"main.py").write_text("from settings import effective\nroute, timeout = effective('prod')\n")
    (path/"settings.py").write_text("import tomllib\nfrom pathlib import Path\ndef effective(env):\n    config = tomllib.loads(Path('routes.toml').read_text())\n    selected = config['alias'][env]\n    section = config['profiles'][selected]\n    return section['route'], config['overrides'].get(selected, section['timeout'])\n")
    (path/"routes.toml").write_text(f'[alias]\nprod="green"\n[profiles.blue]\nroute="old-staging"\ntimeout=19\n[profiles.green]\nroute="{route}"\ntimeout=25\n[overrides]\ngreen={timeout}\n')
    body = config["agents"]["explore"]["request"]["body"]
    body.pop("reasoning_effort", None)
    if effort == "low": body["reasoning_effort"] = "low"
    if verified:
        provider = config["providers"]["infernix"]
        provider["settings"] = {"baseURL":f"http://127.0.0.1:18075/{effort}/v1"}
        model = provider["models"]["infernix-worker"]
        model["capabilities"]["reasoning"] = {"supported":True,"effort":["low","medium","xhigh"]}
        for key in ("settings","body"): model.pop(key,None)
        if effort=="low":
            model["settings"] = {"reasoningEffort":"low"}
            model["body"] = {"reasoning_effort":"low"}
    override = root / (effort+".json")
    override.write_text(json.dumps(config))
    prompt = ("Launch exactly two Explore subagents in parallel in one turn. Each must inspect the current working directory. "
              "Give the first ONLY this task: read version.txt and return the release_marker value. "
              "Give the second ONLY this task: trace main.py through its imported code and config, state the effective production route and timeout. "
              "Wait for both results and quote their answers briefly.")
    start = time.monotonic()
    at = datetime.now(timezone.utc).isoformat()
    try:
        p = subprocess.run([str(cli),"run","--standalone","--archived","--title",f"N1X tuning {run}",
                      "--model","infernix/infernix-hc","--format","json",prompt], cwd=path,
                      env={**os.environ,"OPENCODE_CONFIG":str(override)},capture_output=True,timeout=240)
        rows = []
        for line in p.stdout.splitlines():
            try: event = json.loads(line)
            except ValueError: continue
            part = event.get("part",{})
            if part.get("tool") != "subagent": continue
            state = part.get("state",{})
            tm = state.get("time",{})
            out = str(state.get("output",""))
            args = state.get("input",{})
            rows.append({"status":state.get("status"),"agent":args.get("subagent_type",args.get("agent","")), "task":args.get("prompt",args.get("description","")),
                         "output":out,"start":tm.get("start"),"end":tm.get("end")})
        result = dict(code=p.returncode,workers=rows,stderr=p.stderr.decode(errors="replace")[-400:] if p.returncode else "")
        (root/f"events-{run}.jsonl").write_bytes(p.stdout)
    except subprocess.TimeoutExpired:
        result = {"error":"timeout"}
    result.update(run=run,effort=effort,pair=pair,start=at,wall=round(time.monotonic()-start,3),expected=[marker,route,str(timeout)])
    with (root/("verified-results.jsonl" if verified else "reason-results.jsonl")).open("a") as f: print(json.dumps(result),file=f)
    print(run,effort,result.get("code"),len(result.get("workers",[])),result["wall"],flush=True)

