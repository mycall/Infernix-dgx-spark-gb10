"""Show actual worker attempts and answer excerpts for manual grading."""
import json, pathlib
root=pathlib.Path(__file__).resolve().parent
def gather():
    allrows=[]
    for name in ["reason-results.jsonl","verified-results.jsonl"]:
        if (root/name).exists():
            allrows.extend(json.loads(s) for s in (root/name).read_text().splitlines())
    return allrows
if __name__=="__main__":
    for r in gather():
        expected=r["expected"]
        print("run",r["run"],r["effort"],r["wall"])
        for w in r["workers"]:
            out=w["output"]
            task=w["task"].lower()
            kind="lookup" if ("version.txt" in task or "release_marker" in task) and "effective production" not in task else "trace"
            ans=expected[:1] if kind=="lookup" else expected[1:]
            print(kind,w["status"],round((w["end"]-w["start"])/1000,2),all(s in out for s in ans),out.split("</subagent>")[0][-140:].encode("ascii","replace").decode().replace("\n"," "))

