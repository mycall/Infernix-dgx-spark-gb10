const fs = require('fs');
const path = require('path');
const dir = __dirname;
const read = k => fs.readFileSync(path.join(dir,'k'+k+'-width.jsonl'),'utf8').trim().split(/\r?\n/).map(l => JSON.parse(l.replace(/^\uFEFF/,'')));
const median = a => {const v=[...a].sort((x,y)=>x-y);return (v[(v.length-1)>>1]+v[v.length>>1])/2;};
const sum = a=>a.reduce((x,y)=>x+y,0);
const round = n=>Number(n.toFixed(3));
const sets=[read(3),read(5)];
const counts=Array.from({length:1000},(_,i)=>i+1).join('\n');
const changed=Array.from({length:16},(_,i)=>i+1).join('\n')+'\nSTART\n'+Array.from({length:1200},(_,i)=>i+101).join('\n');
function valid(w,r) {
 const choice=r.r.choices[0], t=(choice.message.content||'').trim();
 if(w.case.endsWith('tool'))return choice.finish_reason==='stop'&&t===['AGENT-0000:23','AGENT-0001:30'][r.slot];
 const index=w.case==='single-prose'?1:r.slot%4;
 if(index===0)return r.r.usage.completion_tokens===128&&t.length>0&&counts.startsWith(t);
 if(index===2)return t.startsWith('1\n')&&changed.startsWith(t)&&t.includes('START');
 return r.r.usage.completion_tokens===128&&choice.finish_reason==='length';
}
const all=[];
for(const c of [...new Set(sets[0].map(w=>w.case))]){
 const runs=sets.map(s=>s.filter(w=>w.case===c).sort((a,b)=>a.rep-b.rep));
 const metrics=runs.map(ws=>{
   const rows=ws.flatMap(w=>w.rows),tokens=ws.map(w=>sum(w.rows.map(r=>r.r.usage.completion_tokens)));
   return {wall:median(ws.map(w=>w.wall)),tps:median(ws.map((w,i)=>tokens[i]/w.wall)),tokens:tokens.join('/'),correct:sum(ws.map(w=>w.rows.filter(r=>valid(w,r)).length)),rows:rows.length,
   a:sum(rows.map(r=>r.r.timings.draft_n_accepted||0)),n:sum(rows.map(r=>r.r.timings.draft_n||0)),cache:rows.map(r=>r.r.timings.cache_n||0).join('|')};
 });
 const [a,b]=metrics;
 const equal=sum(runs[0].map((w,i)=>w.rows.filter(r=>r.r.choices[0].message.content===runs[1][i].rows.find(x=>x.slot===r.slot).r.choices[0].message.content).length));
 const changes=runs[0].map((w,i)=>(runs[1][i].wall/w.wall-1)*100);
 const result={workload:c,k3_s:round(a.wall),k5_s:round(b.wall),k5_wall_change_pct:round(100*(b.wall/a.wall-1)),k3_tps:round(a.tps),k5_tps:round(b.tps),paired_k5_wall_changes_pct:changes.map(round).join('/'),k3_token_totals:a.tokens,k5_token_totals:b.tokens,k3_checks:a.correct,k5_checks:b.correct,requests_each:a.rows,equal_text:equal,k3_accepted:a.a,k3_drafted:a.n,k5_accepted:b.a,k5_drafted:b.n,k3_cached:a.cache,k5_cached:b.cache};
 all.push(result); console.log(c,JSON.stringify(result));
}
fs.writeFileSync(path.join(dir,'results.csv'),[Object.keys(all[0]).join(','),...all.map(r=>Object.values(r).join(','))].join('\n')+'\n');
