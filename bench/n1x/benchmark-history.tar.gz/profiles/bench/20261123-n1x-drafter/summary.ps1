$ErrorActionPreference='Stop'
function Mean($nums){[Math]::Round(($nums|Measure-Object -Average).Average,3)}
$base=$PSScriptRoot
$all=@(foreach($backend in 'DFlash','MTP'){
 $g=Get-Content "$base/grid-$backend.json" -Raw|ConvertFrom-Json
 foreach($t in 0,1){foreach($c in 1..4){$cell=@($g|Where-Object {$_.trial -eq $t -and $_.clients -eq $c})
  if($cell.Count -ne 5){continue}
  foreach($w in 'count','explanation','inventory-warm','inventory-setup'){
   $v=@($cell|Where-Object {if($w -eq 'inventory-warm'){$_.phase -in 'tool','final'}elseif($w -eq 'inventory-setup'){$_.phase -eq 'setup'}else{$_.work -eq $w}})
   $rows=@($v|ForEach-Object {$_.rows})
   [pscustomobject]@{backend=$backend;trial=$t;clients=$c;work=$w;elapsed_s=[math]::Round(($v.wall_s|Measure-Object -Sum).Sum,3);successful=(@($rows|Where-Object passed -eq $true).Count);expected=$c*$v.Count;output_tokens=($rows.response.usage.completion_tokens|Measure-Object -Sum).Sum;cache_hits=(@($rows|Where-Object {$_.response.timings.cache_n -gt 0}).Count)}
  }
 }} 
})
$all|Export-Csv "$base/grid-summary.csv" -NoTypeInformation
$all|Group-Object clients,work|ForEach-Object {$df=@($_.Group|Where-Object backend -eq DFlash);$mtp=@($_.Group|Where-Object backend -eq MTP); "$($_.Name) DFlash $($df.elapsed_s -join '/') MTP $($mtp.elapsed_s -join '/') pass=$($df.successful -join ',')/$($mtp.successful -join ',') hits=$($df.cache_hits -join ',')/$($mtp.cache_hits -join ',')"}
$m=@(foreach($backend in 'DFlash','MTP'){
 $items=Get-Content "$base/mixed-$backend.json" -Raw|ConvertFrom-Json
 foreach($i in $items){
  $choice=$i.response.choices[0];$text=$choice.message.content
  $sha=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($text)))
  $correct=$choice.finish_reason -eq 'length' -and $i.response.usage.completion_tokens -eq 128
  if($i.work -eq 'count'){$correct=$correct -and $text.Trim() -ceq ((1..46) -join [char]10)}
  [pscustomobject]@{backend=$backend;phase=$i.phase;trial=$i.trial;work=$i.work;wall_s=[math]::Round($i.wall_s,3);latency_s=[math]::Round($i.latency_s,3);decode_tps=[math]::Round($i.response.timings.predicted_per_second,2);accepted=$i.response.timings.draft_n_accepted;drafted=$i.response.timings.draft_n;output_tokens=$i.response.usage.completion_tokens;passed=$correct;sha256=$sha}
 }
})
$m|Export-Csv "$base/mixed-summary.csv" -NoTypeInformation
$m|Group-Object backend,phase,work|ForEach-Object {"$($_.Name) wall $(Mean $_.Group.wall_s) latency $(Mean $_.Group.latency_s) passed=$($_.Group.passed -join ',') hashes=$(@($_.Group.sha256|Sort-Object -Unique).Count)"}
