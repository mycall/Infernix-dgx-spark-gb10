import sys,json,re
from pathlib import Path
p=Path(sys.argv[1])
def j(name):return json.loads((p/name).read_text(encoding='utf-8-sig'))
def rows(name):
 q=p/name
 return [json.loads(x) for x in q.read_text(encoding='utf-8-sig').splitlines()] if q.exists() else []
def rounds(name):
 txt=(p/name).read_text()
 return {int(b):int(v) for b,v in re.findall(r'^infernix_decode_batch_rounds_total\{batch="(\d+)"\} (\d+)$',txt,re.M)}
g=j('summary.json')[0]
a,b=rounds('r0-c2-after.prom'),rounds('r0-c2-before.prom')
stats=dict(score=g['correct_tasks'],planned=g['planned_tasks'],wall=round(g['elapsed_s'],3),decode_batch_rounds={k:a[k]-b[k] for k in a if a[k]>b[k]})
for sess in g['sessions']:
 rs=sess['requests'];stats['session'+str(sess['session'])]=dict(score=sess['correct_tasks'],cold_ttft=[round(r['client_ttft_s'],3) for r in rs if r['phase']=='cold-selection' and r.get('client_ttft_s')],cache=[r['timing'].get('cached_tokens') for r in rs],prefill_inputs=[r['usage'].get('prompt_tokens') for r in rs],final_content=[(r.get('content') or '')[:120] for r in rs if r['phase']=='tool-continuation'])
print(json.dumps(stats,indent=2))
