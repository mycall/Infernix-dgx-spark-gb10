$ErrorActionPreference='Stop'
$dir=$PSScriptRoot
wslc logs infernix-bench-plain-1 2>&1|Out-File "$dir/plain-1.log"
wslc stop infernix-bench-plain-1
if($LASTEXITCODE){throw 'Could not stop plain benchmark'}
try{
    & "$dir/launch.ps1" boundary4k 0 4096
    if($LASTEXITCODE){throw 'Could not launch breakpoint benchmark'}
    & "$dir/ready.ps1" infernix-bench-boundary4k-0
    & "$dir/replay.ps1" mtp4k 0 0 -Boundary
    wslc logs infernix-bench-boundary4k-0 2>&1|Out-File "$dir/mtp4k-boundary-0.log"
}finally{
    wslc stop infernix-bench-boundary4k-0
    $when=[DateTimeOffset]::UtcNow.AddSeconds(-1).ToUnixTimeSeconds()
    wslc start infernix-hc4
    if($LASTEXITCODE){throw 'Failed to restart original service'}
    $ready=wslc logs --follow --since $when infernix-hc4 2>&1 | ForEach-Object {"$_"} | Where-Object {$_ -match 'listening on http|FATAL| ERROR '} | Select-Object -First 1
    if($ready -notmatch 'listening on http'){throw "Original server failed to start: $ready"}
    (Invoke-RestMethod http://127.0.0.1:8001/health).status
}
