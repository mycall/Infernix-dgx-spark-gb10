"""Loopback-only test adapter. Forward streaming unchanged, record and apply worker effort."""
import http.client, json, pathlib, threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
root = pathlib.Path(__file__).resolve().parent
class Forward(BaseHTTPRequestHandler):
    def do_POST(self):
        mode, api = self.path.strip("/").split("/",1)
        if mode not in ["low","default"] or api!="v1/chat/completions":
            self.send_error(404); return
        data=json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        cap=data.get("max_tokens",data.get("max_completion_tokens"))
        worker=cap==8192 and len(data.get("tools",[]))==7
        before=data.get("reasoning_effort")
        if worker and mode=="low": data["reasoning_effort"]="low"
        with (root/"wire.jsonl").open("a") as f:
            print(json.dumps(dict(mode=mode,cap=cap,tools=len(data.get("tools",[])),before=before,after=data.get("reasoning_effort"),worker=worker)),file=f)
        upstream=http.client.HTTPConnection("127.0.0.1",8001,timeout=200)
        try:
            upstream.request("POST","/"+api,body=json.dumps(data).encode(),headers={"Content-Type":"application/json"})
            response=upstream.getresponse()
            self.send_response(response.status)
            self.send_header("Content-Type",response.getheader("Content-Type"))
            self.end_headers()
            while chunk:=response.read1(8192):
                self.wfile.write(chunk); self.wfile.flush()
        finally: upstream.close()
    def log_message(self,*args): pass
if __name__=="__main__": ThreadingHTTPServer(("127.0.0.1",18075),Forward).serve_forever()

