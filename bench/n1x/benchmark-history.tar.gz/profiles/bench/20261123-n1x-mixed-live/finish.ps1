param([int]$Before)
$ErrorActionPreference='Stop'
Wait-Process -Id $Before -ErrorAction SilentlyContinue
if(@(Get-Content "$PSScriptRoot/base1-caps.jsonl").Count -ne 6){throw 'capacity run incomplete'}
function RestartTrial([string]$Name){
  $epoch=[DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
  wslc start $Name
  if($LASTEXITCODE){throw "Could not start $Name"}
  $ready=wslc logs --since "$epoch" --follow $Name 2>&1|ForEach-Object {"$_"}|Where-Object {$_ -match 'listening on http|FATAL| ERROR '}|Select-Object -First 1
  if($ready -notmatch 'listening on http'){throw "$Name failed: $ready"}
  $ready
}
RestartTrial n1x-live-dual3
try { & "$PSScriptRoot/work.ps1" dual shared }
finally {
  wslc stop n1x-live-dual3
  if($LASTEXITCODE){throw 'Could not release experimental GPU'}
  RestartTrial infernix-hc4-dflash2-wslc
  Invoke-RestMethod 'http://127.0.0.1:8001/health'|ConvertTo-Json -Compress
  (Invoke-RestMethod 'http://127.0.0.1:8001/v1/models').data.id
}
