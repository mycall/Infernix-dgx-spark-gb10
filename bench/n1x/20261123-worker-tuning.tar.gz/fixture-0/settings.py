import tomllib
from pathlib import Path
def effective(env):
    config = tomllib.loads(Path('routes.toml').read_text())
    selected = config['alias'][env]
    section = config['profiles'][selected]
    return section['route'], config['overrides'].get(selected, section['timeout'])
