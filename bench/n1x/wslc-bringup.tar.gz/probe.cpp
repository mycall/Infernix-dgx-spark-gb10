#include "models/qwen4_exp/program/ngram_volume.h"
#include <cstdio>
#include <string>
using namespace infernix::models::qwen4_exp;
int main(){
 NgramTableConfig table{};
 table.format=NgramRowFormat::Nvfp4;table.rows=320001536;table.row_bytes=90;
 table.rows_per_block=45;table.block_bytes=4096;table.header_bytes=4096;
 table.blocks=7111146;table.file_bytes=29127258112ULL;
 table.volume_id={0xa7,0x8b,0xa0,0x0a,0x64,0xed,0xe9,0x05,0x1a,0xfd,0xcb,0x90,0x37,0xde,0xea,0xa8};
 const std::string name="/Qwen3.8-Flash-Next-NVIDIA-FP4-Local-Infernix.ngram";
 NgramVolume win("/source"+name,table,false,8ULL<<20), linuxvol("/ple"+name,table,false,8ULL<<20);
 for(unsigned i=0;i<8;++i){
  bool native=i%4==1||i%4==2;
  auto p=(native?linuxvol:win).probe_reads(8192,10);
  std::printf("%s %zu reads %.6f seconds %.0f reads/s\n",native?"linux":"bind",p.reads,p.seconds,p.reads_per_second());
 }
}