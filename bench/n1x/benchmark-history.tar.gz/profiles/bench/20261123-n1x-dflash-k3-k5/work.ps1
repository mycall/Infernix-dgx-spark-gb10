param([string]$Name,[string]$Suite='width',[int]$Port=8002)
$ErrorActionPreference='Stop'
$client=[Net.Http.HttpClient]::new()
$client.Timeout=[timespan]::FromMinutes(3)
$count='Write every integer from 1 to 1000 in ascending order. Put one integer on each line. Begin with 1 and continue without commentary.'
$prose='In at least 300 words, explain how a refrigerator transfers heat, and explain the role of each of the four main components.'
$fresh='Explain in detail how a mechanical clock transfers energy from its mainspring to its escapement. Write at least 400 words.'
$change='First write the integers from 1 through 16, one per line. On the next line write START. Then write every integer starting with 101 in ascending order, one per line, for as long as possible. Output only the requested lines.'
$copyText=((1..16) + @('START') + (101..300)) -join [char]10
$copyPrompt="Transcribe the complete list below exactly, preserving one item per line. Begin with 1 and continue copying through 300. Omit all introductory and closing text. List:`n"+$copyText
function Q($prompt,[int]$seed,[int]$limit){
  @{model='infernix-hc4';messages=@(@{role='user';content=$prompt});temperature=0;seed=$seed;max_tokens=$limit;chat_template_kwargs=@{enable_thinking=$false}}
}
function Wave([string]$case,[array]$requests,[int]$rep){
  $sw=[Diagnostics.Stopwatch]::StartNew()
  $tasks=[Collections.Generic.List[Threading.Tasks.Task]]::new()
  $indexes=[Collections.Generic.List[int]]::new()
  $idxs=0..($requests.Count-1);if($rep%2){[array]::Reverse($idxs)}
  foreach($i in $idxs){
    $payload=[Net.Http.StringContent]::new(($requests[$i]|ConvertTo-Json -Depth 20 -Compress),[Text.Encoding]::UTF8,'application/json')
    $tasks.Add($client.PostAsync("http://127.0.0.1:$Port/v1/chat/completions",$payload));$indexes.Add($i)
  }
  $rows=@(while($tasks.Count){
    $k=[Threading.Tasks.Task]::WaitAny($tasks.ToArray());$time=$sw.Elapsed.TotalSeconds
    $res=$tasks[$k].GetAwaiter().GetResult();$i=$indexes[$k];$tasks.RemoveAt($k);$indexes.RemoveAt($k)
    $raw=$res.Content.ReadAsStringAsync().Result
    if(!$res.IsSuccessStatusCode){throw "$Name $case $i $raw"}
    $r=$raw|ConvertFrom-Json -AsHashtable
    [ordered]@{slot=$i;latency=$time;seed=$requests[$i].seed;limit=$requests[$i].max_tokens;r=$r}
  })
  $record=[ordered]@{name=$Name;case=$case;rep=$rep;wall=($rows.latency|Measure-Object -Maximum).Maximum;rows=$rows}
  ($record|ConvertTo-Json -Depth 28 -Compress)|Add-Content "$PSScriptRoot/$Name-$Suite.jsonl"
  "$Name $case $rep $([Math]::Round($record.wall,3))"
}
$q4=@((Q $count 110 128),(Q $prose 110 128),(Q $change 110 128),(Q $fresh 110 128))
foreach($rep in 0..2){
  $order=@('single-count','single-prose','pair','four','eight')
  if($rep%2){[array]::Reverse($order)}
  foreach($case in $order){
    $qs=switch($case){
      single-count {@($q4[0])}
      single-prose {@($q4[1])}
      pair {@($q4[0],$q4[1])}
      four {$q4}
      eight {$q4+$q4}
    }
    Wave $case @($qs) $rep
  }
}
$fixture=(Get-Content "$PSScriptRoot/../20261122-n1x-best/dffasteager-1.json" -Raw|ConvertFrom-Json -AsHashtable)
foreach($rep in 0..2){
  $qs=@(foreach($i in 0,1){
    $json=($fixture.rows[2].request|ConvertTo-Json -Depth 24).Replace('AGENT-0000',('AGENT-{0:D4}' -f $i)).Replace('AX-0-0',"AX-$i-0")
    $q=$json|ConvertFrom-Json -AsHashtable
    $q.messages[0].content="Shared archive $rep. "+$q.messages[0].content
    $q.messages[-1].content=(@{sku="AX-$i-0";count=23+7*$i}|ConvertTo-Json -Compress)
    $q.seed=110
    $q
  })
  Wave cold-tool @($qs[0]) $rep
  Wave warm-tool $qs $rep
}
