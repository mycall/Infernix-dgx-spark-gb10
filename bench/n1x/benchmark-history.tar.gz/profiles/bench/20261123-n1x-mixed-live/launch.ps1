param([string]$Name,[int]$Cap,[switch]$Dual)
$ErrorActionPreference='Stop'
$a=[Collections.Generic.List[string]]::new([string[]](Get-Content "$PSScriptRoot/../20261123-n1x-drafter/dffasteager-4-launch.json" -Raw|ConvertFrom-Json))
$a[$a.IndexOf('--name')+1]=$Name
$a[$a.IndexOf('--max-concurrency')+1]="$Cap"
if($Dual){$i=$a.IndexOf('infernix:n1x-cu135');$a[$i]='infernix:n1x-mixed-live';$a.InsertRange($i,[string[]]@('--env','INFERNIX_TRY_DUAL=1'))}
wslc @a
if($LASTEXITCODE){throw "launch failed"}
& "$PSScriptRoot/../20261123-n1x-drafter/ready.ps1" $Name
