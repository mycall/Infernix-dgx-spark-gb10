const fs = require('fs');
const path = require('path');
const dir = __dirname;
const files = fs.readdirSync(dir).filter(f => /-(route|caps|cache|probe|copy|shared)\.jsonl$/.test(f));
const waves = files.flatMap(f => fs.readFileSync(path.join(dir,f),'utf8').replace(/^\uFEFF/,'').trim().split(/\r?\n/).filter(Boolean).map(l=>({...JSON.parse(l),suite:f.match(/-(\w+)\.jsonl$/)[1]})));
const median = a=>{a=[...a].sort((a,b)=>a-b);return (a[(a.length-1)>>1]+a[a.length>>1])/2};
const pct95 = a=>[...a].sort((a,b)=>a-b)[Math.ceil(a.length*.95)-1];
const round = n=>Number(n.toFixed(3));
const ints = (a,b)=>Array.from({length:b-a+1},(_,i)=>i+a).join('\n');
const standard = ints(1,1000);
const transition = ints(1,16)+'\nSTART\n'+ints(101,1500);
function work(w,i){return (w.suite==='cache'||w.suite==='shared')?'tool':w.case.startsWith('copy-')?['transition','fresh'][i]:w.suite==='caps'?['count','prose','transition','fresh'][i%4]:w.case.startsWith('switch-')?['transition','fresh'][i]:['count','prose'][i]}
const group = new Map();
for (const w of waves){
 const id = [w.name,w.suite,w.case].join('/');
 if(!group.has(id))group.set(id,[]);
 group.get(id).push(w);
}
const records=[];
for(const [id,ws] of group){
 const rows=ws.flatMap(w=>w.rows), totals=ws.map(w=>w.rows.reduce((s,r)=>s+r.r.usage.completion_tokens,0));
 let numeric=0,bad=0,short=0;
 for(const w of ws)for(const r of w.rows){
   const kind=work(w,r.slot), ch=r.r.choices[0], t=(ch.message.content||'').trim();
   if(kind==='count'||kind==='transition'){numeric++;if(!t||!(kind==='transition'?transition:standard).startsWith(t))bad++}
   if(kind==='tool'){numeric++;if(t!==['AGENT-0000:23','AGENT-0001:30'][r.slot])bad++}
   if(kind!=='tool' && (r.r.usage.completion_tokens!==r.limit || ch.finish_reason!=='length'))short++;
 }
 records.push({id,n:ws.length,wall:round(median(ws.map(w=>w.wall))),min:round(Math.min(...ws.map(w=>w.wall))),max:round(Math.max(...ws.map(w=>w.wall))),slot0:round(median(ws.map(w=>w.rows.find(r=>r.slot===0).latency))),p95:round(pct95(rows.map(r=>r.latency))),tps:round(median(ws.map((w,i)=>totals[i]/w.wall))),checks:numeric,wrong:bad,short,cache:rows.map(r=>r.r.timings.cache_n||0).join('|')});
}
const csv=records.length?[Object.keys(records[0]).join(','),...records.map(r=>Object.values(r).join(','))].join('\n'):'';
fs.writeFileSync(path.join(dir,'measurements.csv'),csv);
for(const r of records)console.log(r.id,r.n,r.wall,r.p95,r.tps,'wrong',r.wrong,'short',r.short,r.id.includes('/cache/')?r.cache:'');
