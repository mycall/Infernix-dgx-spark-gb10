"""Controlled concurrent workers on the same fixture for each paired effort arm."""
import concurrent.futures, json, pathlib, time, urllib.request
root = pathlib.Path(__file__).resolve().parent
url = "http://127.0.0.1:8001/v1/chat/completions"
tool = {"type":"function","function":{"name":"read_file","description":"Read named project source file.","parameters":{"type":"object","properties":{"path":{"type":"string"}},"required":["path"]}}}
def solve(pair,effort,kind):
    fixture=root/f"fixture-{pair*2}"
    expected=(fixture/"version.txt").read_text().strip().split("=")[1] if kind=="lookup" else [["north-archive",47],["east-ledger",83],["west-index",61]][pair]
    prompt=("Read version.txt and return only the exact release marker as a JSON string." if kind=="lookup" else
            "Inspect main.py and its imported settings and configuration. Work out the effective production route and timeout. Return only a JSON array [route,timeout].")
    msgs=[{"role":"system","content":"You are a repository Explore worker. Use read_file to investigate and provide only the requested JSON value. Case "+str(pair)},{"role":"user","content":prompt}]
    calls=[]; reads=[]; answer=None
    start=time.monotonic()
    for step in range(8):
        req=dict(model="infernix-hc4",messages=msgs,tools=[tool],temperature=0,seed=19,max_tokens=8192)
        if effort=="low": req["reasoning_effort"]="low"
        with urllib.request.urlopen(urllib.request.Request(url,json.dumps(req).encode(),{"Content-Type":"application/json"}),timeout=150) as f: r=json.load(f)
        u=r["usage"]
        calls.append(u)
        m=r["choices"][0]["message"]
        tools=m.get("tool_calls") or []
        if not tools:
            answer=(m.get("content") or "").strip()
            break
        msgs.append({"role":"assistant","content":m.get("content") or "","tool_calls":tools})
        for call in tools:
            name=json.loads(call["function"]["arguments"]).get("path","").removeprefix("./")
            reads.append(name)
            content=(fixture/name).read_text() if name in {"version.txt","settings.py","routes.toml","main.py"} else "File not found"
            msgs.append({"role":"tool","tool_call_id":call["id"],"content":content})
    try: parsed=json.loads(answer)
    except (ValueError,TypeError): parsed=None
    needed={"version.txt"} if kind=="lookup" else {"main.py","settings.py","routes.toml"}
    return dict(pair=pair,effort=effort,kind=kind,correct=parsed==expected and needed<=set(reads),answer=answer,reads=reads,wall=time.monotonic()-start,usage=calls)
for pair in range(3):
    for effort in (["default","low"] if pair%2==0 else ["low","default"]):
        with concurrent.futures.ThreadPoolExecutor(2) as pool:
            results=list(pool.map(lambda kind:solve(pair,effort,kind),["lookup","trace"]))
        with (root/"direct-results.jsonl").open("a") as f:
            for row in results: print(json.dumps(row),file=f)
        print(pair,effort,[(r["kind"],r["correct"],round(r["wall"],2)) for r in results],flush=True)


