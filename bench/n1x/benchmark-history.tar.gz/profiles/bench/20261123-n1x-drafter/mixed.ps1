param([string]$Backend)
$ErrorActionPreference='Stop'
$client=[Net.Http.HttpClient]::new()
$prompts=@('Write every integer from 1 to 1000 in ascending order. Put one integer on each line. Begin with 1 and continue without commentary.','In at least 300 words, explain how a refrigerator transfers heat, and explain the role of each of the four main components.')
$previous=@{}
$out=@(foreach($trial in 0..7){
 $tasks=@{};$sw=[Diagnostics.Stopwatch]::StartNew()
 $order=if($trial%2){1,0}else{0,1}
 foreach($idx in $order){
   $q=@{model='infernix-hc4';messages=@(@{role='user';content=$prompts[$idx]});temperature=0;max_tokens=128;chat_template_kwargs=@{enable_thinking=$false}}
   if($trial -ge 4){
     $other=1-$idx
     $q.messages=@(@{role='user';content=$prompts[$other]},@{role='assistant';content=$previous["$($trial-4)/$other"]},@{role='user';content=$prompts[$idx]})
   }
   $body=[Net.Http.StringContent]::new(($q|ConvertTo-Json -Depth 10 -Compress),[Text.Encoding]::UTF8,'application/json')
   $tasks[$idx]=$client.PostAsync('http://127.0.0.1:8002/v1/chat/completions',$body)
 }
 $index=[Threading.Tasks.Task]::WaitAny([Threading.Tasks.Task[]]@($tasks[0],$tasks[1])); $first=$sw.Elapsed.TotalSeconds
 [Threading.Tasks.Task]::WaitAll([Threading.Tasks.Task[]]@($tasks[0],$tasks[1]));$wall=$sw.Elapsed.TotalSeconds
 foreach($idx in 0,1){
  $h=$tasks[$idx].Result;$h.EnsureSuccessStatusCode()|Out-Null
  $r=$h.Content.ReadAsStringAsync().Result|ConvertFrom-Json -AsHashtable
  $previous["$trial/$idx"]=$r.choices[0].message.content
  [ordered]@{trial=$trial;phase=$(if($trial -lt 4){"first"}else{"swapped_workloads"});work=@('count','prose')[$idx];wall_s=$wall;latency_s=$(if($idx -eq $index){$first}else{$wall});response=$r}
 }
})
$out|ConvertTo-Json -Depth 25|Set-Content "$PSScriptRoot/mixed-$Backend.json"

