# N1X mixed-drafter and batch-cap trials

The target was the local Qwen3.8-Flash-Next HC4 W4Dense artifact on one RTX Spark N1X under ARM64 WSLC, CUDA 13.5. All timed requests were greedy. The engine used INT8 KV, 16,384 tokens per request, 65,536 requested pooled KV tokens, a 4,096-token prefill chunk, a 1 GiB host prefix cache, the volume-backed n-gram table, and eager execution. Only one server used the GPU at a time.

## Experimental design

- The stock baseline used DFlash2 K3. The separate trial image retained both drafters, gave each up to three draft tokens per round, and caught both up on each commit. An explicitly selected subgroup ran each proposal path. The target verified the resulting rows together. No target weights were duplicated. The fixed width matches the DFlash2 baseline. It differs from the normal MTP auto policy.
- For two simultaneous tasks, the four assignments were D/D, M/D, D/M and M/M. The first assignment letter refers to the counting request. The second refers to the explanation. The client reversed submission order on alternate repetitions. Each case ran three times per server. Cross-server order was fixed, so a small cross-build difference cannot be attributed to a single change.
- A fresh pair copied a supplied sequence that changes format partway through while the neighbor explained a mechanical clock. The copy lane stayed on DFlash2, stayed on MTP, switched to MTP at the first verified boundary at or beyond 32 output tokens, or switched to MTP and back to DFlash2 at or beyond 64. The neighbor always used DFlash2. The wall-clock metric ends when both HTTP responses arrive. Individual lane times are also in the CSV. Server round times include shared verification and commit. They cannot isolate an individual GPU kernel.
- An initial instruction to generate a two-part list ended naturally after 41 tokens. Its results remain under `switch-*`. The explicit-copy variant under `copy-*` reached the intended 48, 96 and 256 tokens. All four fixed assignments and all live-switch cases produced the same response text in both lanes as their matched production baselines. Counting and copying also matched the expected sequence.
- The tool test replayed a completed tool call on two independent sessions with different expected SKU and inventory counts. The cold and replay waves were timed separately, with actual cache hits recorded for each request. Because a replay can still miss, the additional shared-archive test primes one common prefix and checks the subsequent hits.
- The production batch-cap test held the arrival burst and token budgets constant. Four different requests produced 425 tokens total, or 850 for eight requests. The original two-part list stopped normally at 41 tokens in each copy of the four-request group. Every other request produced 128. Three repetitions per cap measured total output tokens per wall-clock second and the request latencies including queue time.

## Results

Median pair latency over three repetitions was 3.519 s for stock DFlash2 and 3.334 s for D/D, 3.751 s for M/D, 3.753 s for D/M, and 3.550 s for M/M in the trial. D/D also had the lowest median on the new copy-and-clock pair at all output limits.

| Output cap per request | Keep D/D | Start M/D and stay | Switch first lane to MTP at 32 | Switch back to DFlash2 at 64 |
|---:|---:|---:|---:|---:|
| 48 | 2.077 s | 2.197 s | 2.105 s | 2.114 s |
| 96 | 3.552 s | 3.780 s | 3.692 s | 3.603 s |
| 256 | 8.023 s | 8.829 s | 8.735 s | 8.183 s |

The 48-token run ends before the second switch. The first MTP round at the 32-token threshold took a median 86.8 ms across nine once-switching runs, versus 87.7 ms in nine runs already using MTP. Both heads had their state maintained on every commit. The timing includes the neighbor and target work. It cannot establish a zero-cost switch in another implementation. Engine-reported model VRAM increased from 66.83 to 68.17 GiB, and KV cache from 0.82 to 0.89 GiB.

All inventory answers had the correct code and count. With separate cold archives D/D took 10.77 s and M/D took 10.92 s (two-run medians). Repeating the independent sessions yielded partial prefix-cache misses. With a primed shared archive each of the eight timed requests reused 8,192 tokens. D/D took 4.09 and 4.95 s; M/D took 4.31 and 5.23 s on the corresponding inputs.

| Stock DFlash2 lane cap | Four offered, tokens/s | Eight offered, tokens/s | Four offered, median wall | Eight offered, median wall |
|---:|---:|---:|---:|---:|
| 1 | 50.2 | 50.7 | 8.46 s | 16.78 s |
| 2 | 62.8 | 66.0 | 6.76 s | 12.88 s |
| 4 | 74.3 | 75.7 | 5.72 s | 11.23 s |
| 8 | 75.6 | 102.3 | 5.62 s | 8.31 s |

The cap is configured at startup. Active batch sizes change during each burst. This sweep addresses throughput and latency at these two offered loads with short prompts. It does not establish an optimal long-context cap or sampled-decoding policy. The small D/D advantage over stock was between different builds and proposal paths. Co-residency alone cannot be credited for that difference.
## Evidence

- [Measurements](measurements.csv) includes median wall time, range, median slot-zero latency, p95 across requests, tokens per second, early stops and correctness counters. A tool answer counts as correct only if it returns the expected session code and inventory count. Numerical sequences are checked against the expected text. Prose is compared across the matched drafter runs in the round analysis.
- [Round measurements](round-times.csv) records the lane, committed span, actual drafter, decode batch size and elapsed interval around each switch boundary.
- [Trial patch](trial.patch) reproduces the experimental source changes against this checkout. The source guard requires the trial environment switch. Seeds 110–113 select the four deterministic test schedules. This is a test mechanism. The shipping service was restored with its original image and configuration.
- Raw HTTP responses and server logs are in this directory. `work.ps1` drives the requests, `summarize.cjs` aggregates the HTTP measurements, and `rounds.cjs` checks matched output text and extracts server round timings.
