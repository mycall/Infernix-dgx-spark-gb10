$ErrorActionPreference='Stop'
$service='infernix-hc4-dflash2-wslc'
wslc stop $service
if($LASTEXITCODE){throw 'Cannot release baseline GPU'}
try{
 foreach($k in 5,3){
  $name="n1x-hc4-width-$k"
  $a=[Collections.Generic.List[string]]::new([string[]](Get-Content "$PSScriptRoot/../20261123-n1x-drafter/dffasteager-4-launch.json" -Raw|ConvertFrom-Json))
  $a[$a.IndexOf('--name')+1]=$name
  $a[$a.IndexOf('--max-concurrency')+1]='8'
  $a[$a.IndexOf('--draft-tokens')+1]="$k"
  wslc @a
  if($LASTEXITCODE){throw "launch failed: $name"}
  try{
    & "$PSScriptRoot/../20261123-n1x-drafter/ready.ps1" $name
    & "$PSScriptRoot/work.ps1" "k$k"
  }finally{
    wslc logs $name 2>&1|Out-File "$PSScriptRoot/k$k.log" -Encoding utf8
    wslc stop $name
  }
 }
}finally{
 $epoch=[DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
 wslc start $service
 if($LASTEXITCODE){throw 'Service restart failed'}
 wslc logs --since "$epoch" --follow $service 2>&1|ForEach-Object {"$_"}|Where-Object {$_ -match 'listening on http|FATAL| ERROR '}|Select-Object -First 1
 Invoke-RestMethod 'http://127.0.0.1:8001/health'|ConvertTo-Json -Compress
}
