import concurrent.futures
import json
import re
import threading
import time
import urllib.request
from pathlib import Path

base = 'http://127.0.0.1:8001'
model = 'infernix-hc4'
def post(path, obj, timeout=600):
    req = urllib.request.Request(base+path, data=json.dumps(obj).encode(), headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.load(r)
def metrics(tag):
    with urllib.request.urlopen(base+'/metrics', timeout=5) as r:
        s=r.read().decode()
    Path('pressure-'+tag+'.prom').write_text(s)
    return {k: int(v) for k,v in re.findall(r'^(infernix_(?:preemptions_total|.*restores_total|.*resum\w+_total|decode_batch_rounds_total\{batch="[12]"\})) (\d+)$',s,re.M)}
seals=['TULIP-7391','CEDAR-4803']
def msgs(i,chars):
    row=('Inventory archive for '+['violet','amber'][i]+': this entry has been reviewed and filed.\n')
    filler=(row*(chars//len(row)+1))[:chars]
    return [{'role':'system','content':f'Archive ledger {i}. Your job is to transcribe records precisely. Return raw JSON only.'},
            {'role':'user','content':f'The authoritative seal of this ledger is {seals[i]}.\n'+filler+'\nEnd of archive. Return exactly one JSON object with two keys, in order: "rows" then "seal". "rows" must be a JSON array of every integer from 1 through 320 inclusive, in ascending order, with no omissions. After the array, give the authoritative seal from the beginning of the archive as the value of "seal".'}]
def calibrate(i):
    lo,hi=1,1200000
    while lo<=hi:
        m=(lo+hi)//2
        messages=msgs(i,m)
        n=post('/v1/responses/input_tokens',{'model':model,'input':messages})['input_tokens']
        if abs(n-131180)<=6: return messages,n
        if n<131180:lo=m+1
        else:hi=m-1
    raise ValueError('calibration failed')
def run(i,prompt,barrier):
    messages,expected_n=prompt
    barrier.wait()
    start=time.monotonic()
    resp=post('/v1/chat/completions',{'model':model,'messages':messages,'temperature':0,'max_tokens':2800,
             'chat_template_kwargs':{'enable_thinking':False},'response_format':{'type':'json_object'}})
    elapsed=time.monotonic()-start
    choice=resp['choices'][0]; content=choice['message']['content']
    try: got=json.loads(content)
    except (ValueError,TypeError): got=None
    correct=choice['finish_reason']=='stop' and got=={'rows':list(range(1,321)),'seal':seals[i]}
    obj={'worker':i,'calibrated':expected_n,'wall_s':elapsed,'correct':correct,'response':resp}
    Path(f'pressure-{i}.json').write_text(json.dumps(obj,indent=2))
    return {k:obj[k] for k in ('worker','calibrated','wall_s','correct')} | {'usage':resp['usage'],'finish':choice['finish_reason']}
pair=[calibrate(i) for i in range(2)]
before=metrics('before')
barrier=threading.Barrier(2)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    futures=[pool.submit(run,i,p,barrier) for i,p in enumerate(pair)]
    results=[f.result() for f in futures]
after=metrics('after')
summary={'results':results,'delta':{k:after[k]-v for k,v in before.items() if k in after}}
Path('pressure-summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary))
