"""Measure client-visible streaming gaps when a fresh long prefill arrives."""
import concurrent.futures, hashlib, json, pathlib, sys, threading, time, urllib.request
port,chunk,series=sys.argv[1:4]
root=pathlib.Path(__file__).resolve().parent
url=f"http://127.0.0.1:{port}/v1/chat/completions"
def stream(prompt,cap,first=None):
    args={"model":"infernix-hc4","messages":[{"role":"user","content":prompt}],"temperature":0,"max_tokens":cap,"stream":True,"stream_options":{"include_usage":True},"chat_template_kwargs":{"enable_thinking":False}}
    stamps,parts=[],[]
    usage={}
    start=time.monotonic()
    with urllib.request.urlopen(urllib.request.Request(url,json.dumps(args).encode(),{"Content-Type":"application/json"}),timeout=170) as resp:
        for raw in resp:
            if not raw.startswith(b"data:") or b"[DONE]" in raw: continue
            obj=json.loads(raw[5:])
            if obj.get("usage"): usage=obj["usage"]
            for choice in obj.get("choices",[]):
                content=choice.get("delta",{}).get("content")
                if content:
                    stamps.append(time.monotonic())
                    parts.append(content)
                    if first: first.set()
    return start,stamps,time.monotonic(),usage,"".join(parts)
for trial in range(5):
    # Same inputs across settings; separate salts per series for repeat on original instance.
    salt=hashlib.sha256(f"mixed-{series}-{trial}".encode()).hexdigest()[:16]
    prompt=f"Batch {salt}. Write the positive integers in order starting at 1, one per line, through 1000. No commentary."
    long=f"Case {salt}. Read the following inventory, then answer the question at the end.\n"+"A region contains numbered shelves for public archival reference.\n"*1800+"\nReply with exactly this confirmation: OK"
    first=threading.Event()
    with concurrent.futures.ThreadPoolExecutor(2) as pool:
        sf=pool.submit(stream,prompt,512,first)
        if not first.wait(90): raise RuntimeError("No first response")
        lf=pool.submit(stream,long,24)
        short,large=sf.result(),lf.result()
    s,st,se,su,so=short
    l,lt,le,lu,lo=large
    gaps=[b-a for a,b in zip(st,st[1:]) if a<=lt[0] and b>=l]
    row=dict(chunk=int(chunk),series=series,trial=trial,warmup=(trial==0),gap=max(gaps) if gaps else None,overlap=st[-1]>l,
             short_usage=su,long_usage=lu,long_answer=lo,short_start=so[:24],short_hash=hashlib.sha256(so.encode()).hexdigest(),
             short_ttft=st[0]-s,long_ttft=lt[0]-l,short_wall=se-s,total=max(le,se)-s,short_events=[round(t-s,5) for t in st],long_start=l-s)
    with (root/f"mixed-{chunk}-{series}.jsonl").open("a") as f: print(json.dumps(row),file=f)
    print(chunk,series,trial,round(row["gap"] or 0,2),round(row["total"],2),lo,flush=True)


# Check the standalone cold-prefill cost of reducing the scheduling unit.
for trial in range(2):
    salt=hashlib.sha256(f"solo-{series}-{trial}".encode()).hexdigest()[:16]
    prompt=f"Record {salt}. Read this inventory.\n"+"A region contains numbered shelves for public archival reference.\n"*2900+"\nReply with exactly this confirmation: OK"
    start,stamps,end,usage,answer=stream(prompt,24)
    row=dict(chunk=int(chunk),series=series,trial=trial,ttft=stamps[0]-start,wall=end-start,usage=usage,answer=answer)
    with (root/f"solo-{chunk}-{series}.jsonl").open("a") as f: print(json.dumps(row),file=f)
    print("solo",chunk,series,trial,round(row["ttft"],2),answer,flush=True)

# Check whether the faster cold-prefill setting preserves ordinary tool-turn reuse.
if chunk=="8192" or series=="repeat":
    import subprocess
    subprocess.run([sys.executable,str(root/"chunk_cache.py"),port,chunk],check=True)
if series=="repeat":
    import subprocess
    subprocess.run([sys.executable,str(root/"cache_quality.py")],check=True)
