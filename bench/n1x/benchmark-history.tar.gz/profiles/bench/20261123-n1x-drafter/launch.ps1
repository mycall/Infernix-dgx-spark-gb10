param([string]$Variant='plain',[string]$Trial='0',[int]$Chunk=512,[int]$Port=8002,[string]$ContainerName)
$ErrorActionPreference='Stop'
$leaf='Qwen3.8-Flash-Next-NVIDIA-FP4-Local-Infernix-HC4-W4Dense'
$m=Join-Path 'C:\Users\michael\models' $leaf
$t=Join-Path $PWD tools\chat_templates
$name=if($ContainerName){$ContainerName}else{"infernix-bench-$Variant-$Trial"}
$argsList=@('run','-d','--name',$name,'--gpus','all','--pull','never','--mount',"type=bind,source=$m,target=/model,readonly",'--mount','type=volume,source=infernix-hc4-ple-a78ba00a,target=/ple,readonly','--mount',"type=bind,source=$t,target=/templates,readonly",'-p',"127.0.0.1:${Port}:8002",'infernix:n1x-cu135','infernix-serve',"/model/$leaf.infernix",'--model-id','infernix-hc4','--ngram-volume','/ple/Qwen3.8-Flash-Next-NVIDIA-FP4-Local-Infernix.ngram','--ngram-residency','volume','--ngram-cache-mib','512','--chat-template','/templates/qwen3_8.jinja','--kv-dtype','int8','--max-context','16384','--kv-capacity','16384','--host-context-mib','1024','--max-concurrency','1','--prefill-chunk',"$Chunk",'--default-max-tokens','128','--host','0.0.0.0','--port','8002')
if($Variant -in @('mtp','mtp4k','boundary4k')){ $argsList+=@('--spec','mtp','--draft-tokens','auto') }
if($Variant -eq 'a4mtp'){ $argsList+=@('--spec','mtp','--draft-tokens','auto','--expert-a4-activations') }
if($Variant -in @('dflash4k','dfnative','dfnarrow','dfpatched','dffasteager','dfeager','dfexact')){
    $idx=[array]::IndexOf($argsList,'infernix:n1x-cu135')
    $draftDir='C:\Users\michael\models\Qwen3.8-Flash-Next-DFlash2-Infernix'
    $argsList=@($argsList[0..($idx-1)])+@('--mount',"type=bind,source=$draftDir,target=/draft,readonly")+@($argsList[$idx..($argsList.Count-1)])
    $argsList+=@('--spec','dflash2','--draft-model','/draft/Qwen3.8-Flash-Next-DFlash2-Infernix.infernix','--draft-tokens','3','--draft-tree-nodes','0')
}
if($Variant -eq 'dfnative'){
    $list=[Collections.Generic.List[string]]::new([string[]]$argsList)
    $list.RemoveRange($list.IndexOf('--chat-template'),2)
    $list.RemoveRange($list.IndexOf("type=bind,source=$t,target=/templates,readonly")-1,2)
    $argsList=$list.ToArray()
}
if($Variant -eq 'dfnarrow'){
    $i=[array]::IndexOf($argsList,"type=bind,source=$t,target=/templates,readonly")
    $argsList[$i]="type=bind,source=$PSScriptRoot,target=/templates,readonly"
    $argsList[[array]::IndexOf($argsList,'/templates/qwen3_8.jinja')]='/templates/qwen3_8_scoped.jinja'
}
if($Variant -in @('dfexact','dfeager')){$argsList+='--reproducible'}
if($Variant -in @('dfeager','dffasteager')){$argsList+='--no-cuda-graph'}
if($Variant -eq 'mtp4k'){$argsList+='--no-cuda-graph'}
$argsList|ConvertTo-Json|Set-Content "$PSScriptRoot/$Variant-$Trial-launch.json"
& wslc @argsList
exit $LASTEXITCODE









