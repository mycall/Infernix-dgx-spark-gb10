param([string]$Name,[string]$Root='http://127.0.0.1:8001',[int]$FirstSeed=0,[int]$SeedCount=12,[int]$Repeats=2)
$cases=foreach($rep in 0..($Repeats-1)){foreach($seed in $FirstSeed..($FirstSeed+$SeedCount-1)){
    $q=@{model='infernix-hc4';messages=@(@{role='user';content='hi'});max_tokens=32;temperature=1;seed=$seed}
    $r=Invoke-WebRequest "$Root/v1/chat/completions" -ContentType application/json -Body ($q|ConvertTo-Json -Depth 8 -Compress) -Method Post -SkipHttpErrorCheck
    $j=$r.Content|ConvertFrom-Json -AsHashtable
    [pscustomobject]@{rep=$rep;seed=$seed;status=[int]$r.StatusCode;response=$j}
}}
$cases|ConvertTo-Json -Depth 22|Set-Content "$PSScriptRoot/$Name-sampled.json"
$cases|Group-Object status|Select-Object Count,Name
$cases|Where-Object status -ne 200|Select-Object rep,seed,status
