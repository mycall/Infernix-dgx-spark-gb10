param([string]$Variant,[int]$Trial,[string]$Root='http://127.0.0.1:8002')
$ErrorActionPreference='Stop'
$q=@{model='infernix-hc4';messages=@(@{role='user';content='Write every integer from 1 to 1000 in ascending order. Put one integer on each line. Begin with 1 and continue without commentary.'});chat_template_kwargs=@{enable_thinking=$false};temperature=0;max_tokens=128}
$body=ConvertTo-Json $q -Depth 7
$rows=foreach($i in 1..3){
    $res=Invoke-RestMethod "$Root/v1/chat/completions" -Method Post -ContentType 'application/json' -Body $body
    [ordered]@{repeat=$i;response=$res}
}
@{request=$q;rows=$rows}|ConvertTo-Json -Depth 22|Set-Content "$PSScriptRoot/$Variant-$Trial-fixed128.json"
$rows|ForEach-Object {"fixed $($_.response.timings.predicted_n) $($_.response.timings.predicted_per_second)" }

